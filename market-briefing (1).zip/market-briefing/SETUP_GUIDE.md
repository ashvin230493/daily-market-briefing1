# 📰 Daily Market Briefing — Setup Guide

## What you need
- A free GitHub account → https://github.com
- A free Anthropic API account → https://console.anthropic.com
- Your Gmail account

---

## Step 1 — Create a GitHub Repository

1. Go to https://github.com/new
2. Name it: `daily-market-briefing`
3. Set it to **Private**
4. Click **Create repository**

---

## Step 2 — Upload the files

Upload these 3 files to your repo (drag & drop on the GitHub page):
- `market_briefing.py`
- `requirements.txt`
- `.github/workflows/daily_briefing.yml`  ← must be in that exact folder path

To create the workflow file in the right place:
1. Click **Add file → Create new file**
2. In the name box type: `.github/workflows/daily_briefing.yml`
3. Paste the contents of `daily_briefing.yml`
4. Click **Commit changes**

---

## Step 3 — Get your Anthropic API Key

1. Go to https://console.anthropic.com
2. Click **API Keys → Create Key**
3. Copy the key (starts with `sk-ant-...`)

---

## Step 4 — Set up Gmail App Password

You need a special App Password (NOT your Gmail login password):

1. Go to https://myaccount.google.com/security
2. Under "How you sign in to Google" → enable **2-Step Verification** (if not already on)
3. Then go to https://myaccount.google.com/apppasswords
4. Select app: **Mail** | Select device: **Other** → type "MarketBriefing"
5. Click **Generate** → copy the 16-character password shown

---

## Step 5 — Add Secrets to GitHub

1. In your GitHub repo, go to **Settings → Secrets and variables → Actions**
2. Click **New repository secret** and add each of these 4:

| Secret Name | Value |
|---|---|
| `ANTHROPIC_API_KEY` | Your Anthropic API key (`sk-ant-...`) |
| `GMAIL_SENDER` | Your Gmail address (e.g. `ashvin@gmail.com`) |
| `GMAIL_APP_PASSWORD` | The 16-char App Password from Step 4 |
| `GMAIL_RECEIVER` | Email to receive briefings (can be same Gmail) |

---

## Step 6 — Test it manually

1. Go to your repo → **Actions** tab
2. Click **Daily Market Briefing** in the left sidebar
3. Click **Run workflow → Run workflow**
4. Wait ~30 seconds → check your inbox!

---

## Schedule

The script runs automatically every day at **9:00 AM Malaysia time**.

To change the time, edit `.github/workflows/daily_briefing.yml` and change the cron line.
Malaysia is UTC+8, so 9am = `0 1 * * *` in UTC cron format.

---

## Cost estimate

- **GitHub Actions**: Free (uses ~1 min/day out of 2,000 free minutes/month)
- **Anthropic API**: ~$0.01–0.02 per day (Claude Sonnet pricing)
- **Gmail**: Free

Total: ~RM1–2 per month.

---

## Troubleshooting

**Email not arriving?**
- Check spam/junk folder
- Verify GMAIL_APP_PASSWORD is correct (no spaces)
- Make sure 2FA is enabled on your Google account

**Script fails in Actions?**
- Click the failed run → expand the step to see the error message
- Most common issue: wrong secret names (must match exactly)
